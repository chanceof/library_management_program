package com.ohgiraffers.repository;

public class MainRepository {


}
